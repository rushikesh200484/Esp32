const express = require("express");
const http = require("http");
const WebSocket = require("ws");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

let latestSensorData = { temperature: 0, humidity: 0 };

app.post("/api/data", (req, res) => {
  latestSensorData = req.body;
  console.log("Received from ESP32:", latestSensorData);

  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(latestSensorData));
    }
  });

  res.sendStatus(200);
});

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

wss.on("connection", ws => {
  console.log("Frontend connected via WebSocket");
  ws.send(JSON.stringify(latestSensorData));
});

const PORT = 3001;
server.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
